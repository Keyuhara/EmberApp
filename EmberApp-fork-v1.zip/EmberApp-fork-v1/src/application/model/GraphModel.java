/**
 * GraphModel is a java class that will represent
 * the model for the Graph scene.
 * 
 * @author The FIRE Benders
 * UTSA CS 3443.003 - Lab 5
 * Spring 2022
 */

package application.model;

import java.util.*;

public class GraphModel 
{
	// store chart data
	private static SortedMap<String, Integer> data = new TreeMap<String, Integer>();
	
	// store variables
	private static int age = 21;
	private static int spending = 75000;
	private static int savings = 6000;
	private static int contributions = 6000;
	
	/**
	 * Constructor required for all model classes
	 * 
	 * @param nothing
	 * @return nothing
	 */
	public GraphModel( )
	{
		// nothing
	}

	/**
	 * convertToInteger() takes the string from the input
	 * and converts it into an integer
	 * 
	 * @param input of an integer in string format
	 * @return quantity of items represented as an integer
	 * @throws NumberFormatException if string is not integer
	 */
	public int convertToInteger( String string ) throws NumberFormatException
	{
		return Integer.parseInt( string );
	}
	
	public void setAge( String ageInput ) throws NumberFormatException
	{
		try
		{
			age = convertToInteger( ageInput );
		}
		catch( NumberFormatException e )
		{
			throw new NumberFormatException( "ERROR: input is not a valid integer" );
		}
		// catch error for negatives
	}
	
	public void setSpending( String spendingInput ) throws NumberFormatException
	{
		try
		{
			// format without $ and commas
			spending = convertToInteger( spendingInput );
		}
		catch( NumberFormatException e )
		{
			throw new NumberFormatException( "ERROR: input is not a valid integer" );
		}
		// catch error for negatives
	}
	
	public void setSavings( String savingsInput ) throws NumberFormatException
	{
		try
		{
			// format without $ and commas
			savings = convertToInteger( savingsInput );
		}
		catch( NumberFormatException e )
		{
			throw new NumberFormatException( "ERROR: input is not a valid integer" );
		}
		// catch error for negatives
	}
	
	public void setContributions( String contributionsInput ) throws NumberFormatException
	{
		try
		{
			// format without $ and commas
			contributions = convertToInteger( contributionsInput );
		}
		catch( NumberFormatException e )
		{
			throw new NumberFormatException( "ERROR: input is not a valid integer" );
		}
		// catch error for negatives
	}
	
	public SortedMap<String, Integer> getOutput( )
	{
		int goal = spending * 25;
		int portfolio = savings;
		int ageTracker = age;
		
		while(portfolio < goal)
		{
			portfolio = (int)(portfolio * 1.07 + contributions);
			data.put( Integer.toString(ageTracker++), portfolio );
		}
		
		for(int i=0; i<10; i++)
		{
			portfolio = (int)(portfolio * 1.07 + contributions);
			data.put( Integer.toString(ageTracker++), portfolio );
		}
		
		return data;
	}
}