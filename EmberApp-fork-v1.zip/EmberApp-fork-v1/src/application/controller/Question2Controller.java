/**
 * Question2Controller is a Java class that will handle 
 * all the interactions on the Question2 scene.
 * This scene serves as the second menu to gather user input.
 * 
 * @author The FIRE Benders
 * UTSA CS 3443.003 - Group Project
 * Spring 2022
 */

package application.controller;

import application.model.GraphModel;
import java.io.*;
import java.net.*;
import javafx.event.*;
import javafx.fxml.*;
import javafx.scene.*;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.*;

public class Question2Controller
{

    @FXML
    private AnchorPane question2Menu;
    
    @FXML
    private TextField savingsInput;

    @FXML
    private Label savingsLabel;
    
    @FXML
    private TextField contributionsInput;

    @FXML
    private Label contributionsLabel;
    
    // class object
	private GraphModel model = new GraphModel();
    
    /**
	 * clickBack() switch to the Question1 scene after clicking the button from the
	 * Question2 scene
	 * 
	 * @param event, ActionEvent object that activates after a button click
	 * @return nothing, void
	 * @throws IOException
	 */
	@FXML
	void clickBack(ActionEvent event) throws IOException
	{
		URL url = new File( "src/application/view/Question1.fxml" ).toURI().toURL();
		question2Menu = FXMLLoader.load( url );
		Scene scene = new Scene( question2Menu );
		Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
		window.setScene( scene );
		window.show();
	}
	
    /**
	 * clickNext() switch to the Graph scene after clicking the button from the
	 * Question2 scene and will also collect and verify the input
	 * 
	 * @param event, ActionEvent object that activates after a button click
	 * @return nothing, void
	 * @throws IOException
	 */
	@FXML
	void clickNext(ActionEvent event) throws IOException
	{
		try
		{
			model.setSavings( savingsInput.getText().trim() );
		}
		catch( NumberFormatException e )
		{
			savingsLabel.setText( "ERROR: input is not a valid integer" );
			savingsLabel.setStyle( "-fx-text-fill: red;" );
		}
		
		try
		{
			model.setContributions( contributionsInput.getText().trim() );
		}
		catch( NumberFormatException e )
		{
			contributionsLabel.setText( "ERROR: input is not a valid integer" );
			contributionsLabel.setStyle( "-fx-text-fill: red;" );
		}
		
		URL url = new File( "src/application/view/Graph.fxml" ).toURI().toURL();
		question2Menu = FXMLLoader.load( url );
		Scene scene = new Scene( question2Menu );
		Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
		window.setScene( scene );
		window.show();
	}

//    @FXML
//    void toIncome(ActionEvent event) throws IOException 
//    {
//    	anchorPane = FXMLLoader.load(getClass().getResource("../view/Question2_Income.fxml"));
//    	Scene scene = new Scene(anchorPane);
//		//scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
//    	Stage window = (Stage) ((Node)event.getSource()).getScene().getWindow();
//    	window.setScene(scene);
//    	window.show();
//    }
//
//    @FXML
//    void toMain(ActionEvent event) throws IOException 
//    {
//    	anchorPane = FXMLLoader.load(getClass().getResource("../view/Main.fxml"));
//    	Scene scene = new Scene(anchorPane);
//		//scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
//    	Stage window = (Stage) ((Node)event.getSource()).getScene().getWindow();
//    	window.setScene(scene);
//    	window.show();
//    }

}