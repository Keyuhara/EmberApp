/**
 * Question1Controller is a Java class that will handle 
 * all the interactions on the Question1 scene.
 * This scene serves as the first menu to gather user input.
 * 
 * @author The FIRE Benders
 * UTSA CS 3443.003 - Group Project
 * Spring 2022
 */

package application.controller;

import application.model.GraphModel;
import java.io.*;
import java.net.*;
import javafx.event.*;
import javafx.fxml.*;
import javafx.scene.*;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.*;

public class Question1Controller
{

    @FXML
    private AnchorPane question1Menu;
    
    @FXML
    private TextField ageInput;

    @FXML
    private Label ageLabel;
    
    @FXML
    private TextField spendingInput;

    @FXML
    private Label spendingLabel;
    
    // class object
	private GraphModel model = new GraphModel();
    
    /**
	 * clickBack() switch to the Main scene after clicking the button from the
	 * Question1 scene
	 * 
	 * @param event, ActionEvent object that activates after a button click
	 * @return nothing, void
	 * @throws IOException
	 */
	@FXML
	void clickBack(ActionEvent event) throws IOException
	{
		URL url = new File( "src/application/view/Main.fxml" ).toURI().toURL();
		question1Menu = FXMLLoader.load( url );
		Scene scene = new Scene( question1Menu );
		Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
		window.setScene( scene );
		window.show();
	}
	
    /**
	 * clickNext() switch to the Question2 scene after clicking the button from the
	 * Question1 scene and will also collect and verify the input
	 * 
	 * @param event, ActionEvent object that activates after a button click
	 * @return nothing, void
	 * @throws IOException
	 */
	@FXML
	void clickNext(ActionEvent event) throws IOException
	{
		try
		{
			model.setAge( ageInput.getText().trim() );
		}
		catch( NumberFormatException e )
		{
			ageLabel.setText( "ERROR: input is not a valid integer" );
			ageLabel.setStyle( "-fx-text-fill: red;" );
		}
		
		try
		{
			model.setSpending( ageInput.getText().trim() );
		}
		catch( NumberFormatException e )
		{
			spendingLabel.setText( "ERROR: input is not a valid integer" );
			spendingLabel.setStyle( "-fx-text-fill: red;" );
		}
		
		URL url = new File( "src/application/view/Question2.fxml" ).toURI().toURL();
		question1Menu = FXMLLoader.load( url );
		Scene scene = new Scene( question1Menu );
		Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
		window.setScene( scene );
		window.show();
	}

//    @FXML
//    void toIncome(ActionEvent event) throws IOException 
//    {
//    	anchorPane = FXMLLoader.load(getClass().getResource("../view/Question2_Income.fxml"));
//    	Scene scene = new Scene(anchorPane);
//		//scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
//    	Stage window = (Stage) ((Node)event.getSource()).getScene().getWindow();
//    	window.setScene(scene);
//    	window.show();
//    }
//
//    @FXML
//    void toMain(ActionEvent event) throws IOException 
//    {
//    	anchorPane = FXMLLoader.load(getClass().getResource("../view/Main.fxml"));
//    	Scene scene = new Scene(anchorPane);
//		//scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
//    	Stage window = (Stage) ((Node)event.getSource()).getScene().getWindow();
//    	window.setScene(scene);
//    	window.show();
//    }

}