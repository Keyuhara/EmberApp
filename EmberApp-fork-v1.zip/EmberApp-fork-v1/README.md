# EmberApp
Ember: A FIRE Calculator

Added the GUI and basic layout for the project.

Todo:
Scene changes.
Make TextFields store values for use in the graph calculation.
The graph itself.
GraphModel.java
Any other tweaks as necessary.
