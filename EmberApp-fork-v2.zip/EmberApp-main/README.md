# EmberApp
1. Project Name:
Ember: A FIRE Calculator

2. Team Name:
The FIRE Benders

3. Team Members:
Kyle Yuhara
Derek Torres
Julian Legere
Mateo Rivas
Daniel Rodriguez

4. Short Description:
The Ember application is a quick and simple calculator designed to figure out how much money you need to save and invest in order to retire early.

5. Known Bugs:
N/A None detected so far.

6. Login Info:
N/A Login is not required.

7. Versions or Other Requirements:
N/A No new API, special installation, or other version of Java is required other than your standard class usage of Java 8 and JavaFX along with SceneBuilder.